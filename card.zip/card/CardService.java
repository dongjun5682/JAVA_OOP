package card;

public class CardService {

}
