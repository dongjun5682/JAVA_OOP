package tv;

public class TVService {
	public void power(){}
	public void channeIup() {}
	public void channeIDown() {}
}
